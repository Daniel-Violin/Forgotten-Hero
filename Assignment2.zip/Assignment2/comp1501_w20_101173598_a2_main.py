import pygame
import csv
import os
import random
import math

from pygame.locals import *

#Mouse constants
MOUSE_LMB = 0
MOUSE_RMB = 1
MOUSE_X = 2
MOUSE_Y = 3
#Size constants and level declaration
level = 0
screenW = 800
screenH = 600
world_wid = 3500
world_hgt = 3500

clock = pygame.time.Clock()
screen = pygame.display.set_mode((screenW, screenH))

#Sets up the main screens from the "img" folder
game_folder = os.path.dirname(os.path.dirname(__file__))
img_folder = os.path.join(game_folder, 'img')
startscreen = pygame.image.load(os.path.join(img_folder, "Title_Page.png")).convert_alpha()
pausescreen = pygame.image.load(os.path.join(img_folder, "pausescreen.png")).convert_alpha()
tutscreen = pygame.image.load(os.path.join(img_folder, "TutorialScreen.png")).convert_alpha()
winscreen = pygame.image.load(os.path.join(img_folder, "WinScreen.png")).convert_alpha()

tile_lst = [[],[],[]]
lava_lst = [[],[],[]]
wall_lst = [[],[],[]]
spike_lst = [[],[],[]]
spike_lava = [[],[],[]]
spike_tile = [[],[],[]]
void_lst = [[],[],[]]
mount_lst = [[],[],[]]
stair_lst = [[],[],[]]
gem_lst = [[],[],[]]
transformingblock_lst = [[],[],[]]
fan = [[],[]]

#State constants
STATE_OPEN = 0
STATE_WAIT = 1
STATE_MOVE = 2
STATE_RIDE = 3
STATE_TUT = 4
STATE_OVER = 5
STATE_WIN = 6

frame_rate = 40
delta_time = 1 / frame_rate
w=32
h=32

#Classes for all objects used in the game
class Tile():
    def __init__(self, x,y):
        self.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32))
        self.x = x
        self.y = y
class Lava():
    def __init__(self, x,y, transformed):
        self.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavatile_center2.jpeg")).convert_alpha(), (32, 32))
        self.x = x
        self.y = y
        self.transformed = transformed
class Wall():
    def __init__(self, x,y):
        self.x = x
        self.y = y
class Empty():
    def __init__(self, x,y):

        self.x = x
        self.y = y
class Spike():
    def __init__(self, x,y):
        self.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "Spikes.jpeg")).convert_alpha(),(32, 32))
        self.x = x
        self.y = y
class Stair():
    def __init__(self, x,y):
        self.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "Play_Button.jpeg")).convert_alpha(),(32, 32))
        self.x = x
        self.y = y
class Bat():
    def __init__(self, x,y):
        self.og_img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Bat1.png")).convert_alpha(),(64, 64))
        self.img = self.og_img
        self.x = x
        self.y = y
        self.rect = Rect(x,y,x+64,y+64)
        self.drawn = False
        self.dx = 0
        self.dy = 0
        self.ddx = 0
        self.ddy = 0
        self.offset = 0
        self.dir = 90
    def update(self, angle):
        self.dir = (self.dir + angle) % 360
        self.offset = (self.offset + angle) % 360
        self.img = pygame.transform.rotate(self.og_img, self.offset)

class Ball():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.vel = [0,0]
        self.destroyed = False
        self.isFired = False


class Gem():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.collected = False
class Player():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "playerdown.png")).convert_alpha(),(32,32))


#Converts CSV Files into 2D lists
def read_csv(file):

    lst = list(csv.reader(open(file)))
    return lst


def get_all_inputs():
    # get the state of the mouse (i.e., button states and pointer position)
    mouse_dict = {}
    (mouse_dict[MOUSE_LMB], _,
     mouse_dict[MOUSE_RMB]) = pygame.mouse.get_pressed()
    (mouse_dict[MOUSE_X], mouse_dict[MOUSE_Y]) = pygame.mouse.get_pos()

    # get the state of the keyboard
    keybd_tupl = pygame.key.get_pressed()

    # look in the event queue for the quit event
    quit_ocrd = False
    for evnt in pygame.event.get():
        if evnt.type == QUIT:
            quit_ocrd = True

    # return all possible inputs
    return mouse_dict, keybd_tupl, quit_ocrd


#Renders the map and the path from the tiles/map.csv file
#Rotates the image depending on the orientation depicted in the csv
def generate_background_surface(level):
    map = os.path.join(game_folder, 'map.csv')
    lst = read_csv(map)
    background = pygame.Surface((world_wid, world_hgt))
    x, y = 0, 0
    for row in lst:
        for col in row:
            #If wall
            if col.startswith("g"):
                img = pygame.image.load(os.path.join(img_folder, "wall.png"))
                if col.startswith("gt"):
                    if col.endswith("b"):
                        img_final = pygame.transform.rotate(img, 180)
                        background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                    else:
                        background.blit(pygame.transform.scale(img.convert_alpha(),(32, 32)), [x, y])
                elif col.startswith("gc"):
                    img = pygame.image.load(os.path.join(img_folder, "wallcap.png"))
                    if col.endswith("l"):
                        img_final = pygame.transform.rotate(img, 90)
                        background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                    elif col.endswith("r"):
                        img_final = pygame.transform.rotate(img, 270)
                        background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                    elif col.endswith("d"):
                        img_final = pygame.transform.rotate(img, 180)
                        background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                    else:
                        background.blit(pygame.transform.scale(img.convert_alpha(),(32, 32)), [x, y])
                elif col.startswith("gm"):
                    img = pygame.image.load(os.path.join(img_folder, "wallmid.png"))
                    if col.endswith("s"):
                        img_final = pygame.transform.rotate(img, 90)
                        background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                    else:
                        background.blit(pygame.transform.scale(img.convert_alpha(),(32, 32)), [x, y])
                elif col.endswith("l"):
                    img = pygame.image.load(os.path.join(img_folder, "wallouter.png"))
                    img_final = pygame.transform.rotate(img, 180)
                    background.blit(pygame.transform.scale(img_final.convert_alpha(),(32, 32)), [x, y])
                else:
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "wallouter.png")).convert_alpha(),(32,32)),[x,y] )
                wall_lst[level].append(Wall(x,y))

            #If blackspace
            elif col == 'b':
                pygame.draw.rect(background, (0,0,0), (x,y,32,32))
                void_lst.append(Empty(x,y))

            #if lava tile
            elif col.startswith('l'):

                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavatile_center2.jpeg")).convert_alpha(),(32, 32)),[x,y])
                if col.endswith("f"):
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"fan.png")).convert_alpha(),(32, 32)), [x, y])
                elif col.endswith("fr"):

                    background.blit(pygame.transform.scale(pygame.transform.rotate(pygame.image.load(os.path.join(img_folder, "fan.png")).convert_alpha(),270),(32, 32)), [x, y])
                else:
                    lava_lst[level].append(Lava(x, y,False))

            #if normal tile
            elif col == 't':
                tile_lst[level].append(Tile(x, y))
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32)),[x,y])

            #if demon bat
            elif col == 'tb':
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32)), [x, y])
                bat = Bat(x,y)
                bat.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Bat1.png")).convert_alpha(),(64, 64))
                mount_lst[level].append(bat)

            #if gem space
            elif col == "tg":
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32)), [x, y])
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Gem1.png")).convert_alpha(),(32, 32)), [x, y])
                gem = Gem(x,y)
                gem_lst[level].append(gem)

            #if spike
            elif col.startswith("s"):
                if col[1] == "t":
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32)), [x, y])
                else:
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavatile_center2.jpeg")).convert_alpha(),(32, 32)), [x, y])
                img = pygame.image.load(os.path.join(img_folder, "Spikes.png"))
                if col[2] == "u":
                    img_final = pygame.transform.rotate(img, 90)
                    background.blit(pygame.transform.scale(img_final.convert_alpha(), (32, 32)),[x, y])
                elif col[2] == "l":
                    img_final = pygame.transform.rotate(img, 180)
                    background.blit(pygame.transform.scale(img_final.convert_alpha(), (32, 32)),[x, y])
                elif col[2] == "d":
                    img_final = pygame.transform.rotate(img, 270)
                    background.blit(pygame.transform.scale(img_final.convert_alpha(), (32, 32)),[x, y])
                else:
                    background.blit(pygame.transform.scale(img.convert_alpha(),(32,32)),[x,y])
                spike_lst[level].append(Spike(x,y))
            #if transforming blocks
            elif col.startswith("mg"):
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavatile_center2.jpeg")).convert_alpha(),(32, 32)), [x, y])
                lava = Lava(x,y,False)
                if col == "mg":
                    transformingblock_lst[0].append(lava)
                    lava_lst[level].append(lava)
                elif col == "mg1":
                    transformingblock_lst[1].append(lava)
                    lava_lst[level].append(lava)
                else:
                    stair_lst[level].append(lava)
                    lava_lst[level].append(lava)
            x += 32
        x = 0
        y += 32

    return background


#main game loop
def main():
    pygame.font.init()

    #Some constants to be used in the loop
    collected_gems = []
    max_v = 4
    oldx = 0
    oldy = 0
    dead = False
    currently_riding = 0


    end = False

    #initializing player and background
    level = 0
    player_x = screenW // 2
    player_y = screenH // 2
    player = Player(screenW//2, screenH//2)
    camera_rect = pygame.Rect(player_x - screenW // 2, player_y - screenH // 2, screenW, screenH)
    background = generate_background_surface(level)

    #Set up game loop
    game_state = STATE_OPEN
    last_state = -1
    cooldown_timer = -1
    next_state = game_state


    while not end:

        #####################################################################################################
        # this is the "inputs" phase of the game loop, where player input is retrieved and stored
        #####################################################################################################

        mouse_dict, keybd_tupl, end = get_all_inputs()
        if cooldown_timer > 0:
            keybd_tupl = tuple([0] * 323)
            cooldown_timer -= 1

        #####################################################################################################
        # this is the "update" phase of the game loop, where the changes to the game world are handled
        #####################################################################################################

        next_state = game_state

        if game_state == STATE_WAIT:
            #if player wants to unpause, return to previous state of game
            if keybd_tupl[K_ESCAPE]:
                next_state = last_state
                cooldown_timer = frame_rate // 2

        if game_state == STATE_MOVE or game_state == STATE_RIDE:

            #if player hits escape, pause game
            if keybd_tupl[K_ESCAPE]:
                next_state = STATE_WAIT
                last_state = game_state
                cooldown_timer = frame_rate // 2

            for mount in mount_lst[level]:

                # position is increased by velocity
                next_mount_x = mount.x + mount.dx
                next_mount_y = mount.y + mount.dy

                # this flag is used for collision detection
                mount_collided_with_wall = False

                # check the position of the mount against each of the walls
                for wall in wall_lst[level]:

                    #If the mount is colliding with a wall, make sure they cannot move through it (set vel and acc to 0)
                    if not (next_mount_x < wall.x-10 or next_mount_x-10 >= wall.x +32 or next_mount_y < wall.y-10 or next_mount_y-10 >= wall.y + 32):
                        mount_collided_with_wall = True
                        mount.dx = 0
                        mount.dy = 0
                        mount.ddx = 0
                        mount.ddy = 0
               #Check if the mount has collided with a spike
                if currently_riding != 0:
                    for spike in spike_lst[level]:
                        if not (next_mount_x < spike.x - 10 or next_mount_x - 10 >= spike.x or next_mount_y < spike.y - 10 or next_mount_y - 10 >= spike.y):
                            dead = True
                #if there is no collision than the mount can move
                if not mount_collided_with_wall:
                    mount.x = next_mount_x
                    mount.y = next_mount_y

                # velocity is increased by acceleration
                mount.dx += mount.ddx
                mount.dy -= mount.ddy

                # ...but there is a maximum possible velocity that the magnitude cannot exceed
                cur_v = pygame.math.Vector2(mount.dx, mount.dy)
                if math.sqrt(cur_v.x ** 2 + cur_v.y ** 2) > max_v:
                    cur_v = cur_v.normalize() * max_v

                # velocity is also reduced by friction NOTE: To make it easier to test you can set the friction to around 0.75
                mount.dx = cur_v.x * .99
                mount.dy = cur_v.y * .99

                # acceleration is always set to zero unless it is a frog that the king is riding
                mount.ddx = 0
                mount.ddy = 0
        if game_state == STATE_RIDE:

            # if the user is pressing up then they want to accelerate in the current direction the frog is facing
            if keybd_tupl[K_UP]:
                currently_riding.ddx = + math.cos(math.radians(currently_riding.dir))
                currently_riding.ddy = + math.sin(math.radians(currently_riding.dir))

            # if the user is pressing down then they want to accelerate in the opposite direction the frog is facing
            if keybd_tupl[K_DOWN]:
                currently_riding.ddx = -math.cos(math.radians(currently_riding.dir))
                currently_riding.ddy = -math.sin(math.radians(currently_riding.dir))

            # if the user presses left then they want to turn counterclockwise
            if keybd_tupl[K_LEFT]:
                currently_riding.update(-6)
            # if the user presses right then they want to turn clockwise
            if keybd_tupl[K_RIGHT]:
                currently_riding.update(6)

            #Check if the player riding a mount is in an area that is blown around by fans
            if ((224 < currently_riding.x < (224 + 11*32)) and (224+21*32)<currently_riding.y<(224+24*32)) \
                    or (224+20*32<currently_riding.x<224+25*32 and 224+26*32< currently_riding.y < 224+26*32+9*32) \
                    or (224+17*32<currently_riding.x<224+25*32 and 224+15*32<currently_riding.y < 224+21*32)\
                    or (224+24*32<currently_riding.x<224+30*32 and 224 < currently_riding.y < 224+32*13):
                #Disorient the mount's direction
                currently_riding.update(-4)

            # if the user presses return then they want to exit the frog
            #Update player position and return bat to it's old position
            if keybd_tupl[K_RETURN]:
                player_x = currently_riding.x
                player_y = currently_riding.y
                currently_riding.dx=0
                currently_riding.dy=0
                currently_riding.ddy=0
                currently_riding.ddx=0
                currently_riding.x = oldx
                currently_riding.y = oldy
                currently_riding = 0
                next_state = STATE_MOVE
                cooldown_timer = frame_rate // 2

            # center the camera on the position of the frog
            if currently_riding != 0:
                camera_rect.center = (currently_riding.x,currently_riding.y)

        if game_state == STATE_MOVE:
            # the future position of the player can be initialized

            next_player_x = player_x
            next_player_y = player_y

            # the player moves according to user input with the arrow keys and the player image is updated
            if keybd_tupl[K_UP]:
                next_player_y = player_y - 2
                player.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "playerup.png")).convert_alpha(),(32, 32))
            if keybd_tupl[K_DOWN]:
                next_player_y = player_y + 2
                player.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "playerdown.png")).convert_alpha(),(32, 32))
            if keybd_tupl[K_LEFT]:
                next_player_x = player_x - 2
                player.img = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, "playerside.png")).convert_alpha(),(32,32))
            if keybd_tupl[K_RIGHT]:
                next_player_x = player_x + 2
                player.img = pygame.transform.scale(pygame.transform.flip(pygame.image.load(os.path.join(img_folder, "playerside.png")).convert_alpha(),True,False),(32,32))


            #Check if player is trying to collect a gem
            for gem in gem_lst[level]:
                if keybd_tupl[K_z]:
                    if ((gem.x - next_player_x) ** 2 + (gem.y - next_player_y) ** 2) < ((16 + 10 + 32) ** 2):
                        gem.collected = True
            #Check if player is trying to go down the stairs to win the game
            for stair in stair_lst[level]:
                if keybd_tupl[K_RETURN]:
                    if ((stair.x - next_player_x) ** 2 + (stair.y - next_player_y) ** 2) < ((16 +10+ 32) ** 2):
                        next_state = STATE_WIN

            player_collided_with_wall = False
            player_collided_with_mount = False
            player_should_die = False

            #Check if player collides with wall
            for wall in wall_lst[level]:
                if not (next_player_x < wall.x-10 or next_player_x-10 >= wall.x +32 or next_player_y < wall.y-10 or next_player_y-10 >= wall.y + 32):
                    player_collided_with_wall = True

            #check if player can mount
            for mount in mount_lst[level]:

                #if the player is trying to control a bat
                if keybd_tupl[K_RETURN]:

                    #Check if the player is close enough to a bat
                    if ((mount.x - next_player_x) ** 2 + (mount.y - next_player_y) ** 2) < ((16 + 10 + 32) ** 2):
                        currently_riding = mount
                        oldx = mount.x
                        oldy = mount.y
                        next_state = STATE_RIDE
                        cooldown_timer = frame_rate // 2

                else:

                    #check if player collided with mount
                    if ((mount.x - next_player_x) ** 2 + (mount.y - next_player_y) ** 2) < (32 ** 2):
                        player_collided_with_mount = True

            #update player position if they are not colliding with wall or mount
            if not player_collided_with_wall and not player_collided_with_mount:
                player_x = next_player_x
                player_y = next_player_y
            camera_rect.center = (player_x, player_y)

            #Check if the player will die when colliding with lava or spikes
            for lava in lava_lst[level]:
                if not (next_player_x < lava.x or next_player_x >= lava.x + 32 or next_player_y < lava.y or next_player_y >= lava.y + 32) and lava.transformed == False:
                    player_should_die = True
            for spike in spike_lst[level]:
                if not (next_player_x < spike.x-10 or next_player_x-10 >= spike.x + 32 or next_player_y < spike.y-10 or next_player_y-10 >= spike.y + 32):
                    player_should_die = True

            #if the player should die then make dead true
            if player_should_die:
                dead = True

        #####################################################################################################
        # this is the "render" phase of the game loop, where a representation of the game world is displayed
        #####################################################################################################

        #Draw opening screen
        if game_state == STATE_OPEN:
            screen.blit(startscreen, (0,0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    end = False
                if keybd_tupl[K_RETURN]:
                    next_state = STATE_TUT
            pygame.display.update()

        #Draw tutorial screen
        elif game_state == STATE_TUT:
            screen.blit(tutscreen, (0,0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    end = True
                if keybd_tupl[K_RETURN]:
                    next_state = STATE_MOVE
            pygame.display.update()
        #Draw win screen
        elif game_state == STATE_WIN:
            screen.blit(winscreen, (0,0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    end = True
            pygame.display.update()
        #Otherwise draw the game
        else:
            #Clear screen
            screen.fill((0,0,0))
            #Update background

            #Put font for number of gems in the top left
            screen.blit(background, (0, 0), camera_rect)
            screen.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Gem1.png")).convert_alpha(),(32, 32)), [0, 0])
            font = pygame.font.SysFont('arial', 32)
            text = font.render("x"+str(len(collected_gems)), True, (255,255,255))
            textRect = text.get_rect()
            textRect.center = (48,16)
            screen.blit(text, textRect)

            #Draw the mounts that are nearby the player
            for mount in mount_lst[level]:
                if camera_rect.colliderect(Rect(mount.x-32, mount.y-32,2*32,2*32)):
                    screen.blit(mount.img, [mount.x-camera_rect.left-24, mount.y-camera_rect.top-48])
            #Clear gems after they have been collected
            for gem in gem_lst[level]:
                if gem.collected:
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Dungeon_Tile_floor.jpeg")).convert_alpha(),(32, 32)), [gem.x, gem.y])
                    gem.collected = False

                    if gem not in collected_gems:
                        collected_gems.append(gem)
            #If two gems are collected, allow player to go to next level
            if len(collected_gems) == 2:

                for block in transformingblock_lst[0]:
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavarock_Center.png")).convert_alpha(),(32, 32)),[block.x, block.y])
                    for lava in lava_lst[level]:
                        if (lava.x == block.x and lava.y  == block.y):
                            lava.transformed = True

            #If four gems are collected, allow player to end game
            elif len(collected_gems) == 4:
                stair = stair_lst[0][0]
                for block in transformingblock_lst[1]:
                    background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Lavarock_Center.png")).convert_alpha(),(32, 32)),[block.x, block.y])
                    for lava in lava_lst[level]:
                        if (lava.x == block.x and lava.y  == block.y) or (lava.x == stair.x and lava.y == stair.y) :
                            lava.transformed = True
                background.blit(pygame.transform.scale(pygame.image.load(os.path.join(img_folder,"Play_Button.jpeg")).convert_alpha(),(32, 32)),[stair.x, stair.y])
            #draw player when they should be drawn
            if not dead and game_state == STATE_MOVE:
                screen.blit(player.img, [screenW//2-16, screenH//2-24])
            #draw pause screen
            if game_state == STATE_WAIT:
                screen.blit(pygame.transform.scale(pausescreen, (400, 300)), (200, 100))
            clock.tick(frame_rate)
            pygame.display.update()


        game_state = next_state
        #If player is dead end the loop
        if dead:
            end = True






if __name__ == '__main__':
    main()
